package com.example.demo;

import org.springframework.web.reactive.function.client.ExchangeStrategies;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;

import java.util.HashSet;
import java.util.Set;

public class TestClient {

    public static void main(String[] args) {
        // 최대 버퍼 크기를 1GB로 설정
        ExchangeStrategies exchangeStrategies = ExchangeStrategies.builder()
                .codecs(configurer -> configurer.defaultCodecs().maxInMemorySize(1000000000))
                .build();

        // WebClient 생성
        WebClient client = WebClient.builder()
                .baseUrl("http://localhost:8080")
                .exchangeStrategies(exchangeStrategies)
                .build();

        // 중복된 메모리 참조 주소를 담을 Set 생성
        Set<Integer> referenceAddressSet = new HashSet<>();

        // Flux는 Reactor 프로젝트의 일부로, 비동기적으로 여러 개의 값을 발생시킬 때 사용
        // range() 메소드를 사용하여 1부터 100까지의 숫자 시퀀스를 발생
        Flux.range(1, 100)
                // 각각의 GET 요청을 처리
                .flatMap(i -> client.get()
                        .uri("/data")
                        .retrieve()
                        .bodyToMono(String.class)
                        // 받아온 응답 본문의 메모리 참조 주소를 출력하고 Set에 추가
                        .map(s -> {
                            int referenceAddress = System.identityHashCode(s);
                            System.out.printf("Reference Address: %d\n", referenceAddress);
                            referenceAddressSet.add(referenceAddress);
                            return referenceAddress;
                        }))
                // 모든 GET 요청이 완료될 때까지 대기
                .blockLast();

        // 중복된 메모리 참조 주소가 있는지 검사하고 결과 출력
        if (referenceAddressSet.size() == 100) {
            System.out.println("All reference addresses are unique.");
        } else {
            System.out.println("There are duplicate reference addresses.");
        }
    }
}