package com.example.demo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Flux;

import java.util.concurrent.ThreadLocalRandom;

@RestController
public class TestController {

    private static final String RANDOM_STRING = generateRandomString(1000);

    @GetMapping("/data")
    public Flux<MyVO> getData() {
        Flux<MyVO> flux = Flux.range(1, 100)
                .map(i -> new MyVO(RANDOM_STRING));
        return flux;
    }

    private static String generateRandomString(int length) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < length; i++) {
            sb.append((char) ThreadLocalRandom.current().nextInt(97, 123));
        }
        return sb.toString();
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class MyVO {
        private String data1;
        private String data2;
        private String data3;
        private String data4;
        private String data5;
        private String data6;
        private String data7;
        private String data8;
        private String data9;
        private String data10;
        private String data11;
        private String data12;
        private String data13;
        private String data14;
        private String data15;
        private String data16;
        private String data17;
        private String data18;
        private String data19;
        private String data20;
        private String data21;
        private String data22;
        private String data23;
        private String data24;
        private String data25;
        private String data26;
        private String data27;
        private String data28;
        private String data29;
        private String data30;
        private String data31;
        private String data32;
        private String data33;
        private String data34;
        private String data35;
        private String data36;
        private String data37;
        private String data38;
        private String data39;
        private String data40;
        private String data41;
        private String data42;
        private String data43;
        private String data44;
        private String data45;
        private String data46;
        private String data47;
        private String data48;
        private String data49;
        private String data50;
        private String data51;
        private String data52;
        private String data53;
        private String data54;
        private String data55;
        private String data56;
        private String data57;
        private String data58;
        private String data59;
        private String data60;
        private String data61;
        private String data62;
        private String data63;
        private String data64;
        private String data65;
        private String data66;
        private String data67;
        private String data68;
        private String data69;
        private String data70;
        private String data71;
        private String data72;
        private String data73;
        private String data74;
        private String data75;
        private String data76;
        private String data77;
        private String data78;
        private String data79;
        private String data80;
        private String data81;
        private String data82;
        private String data83;
        private String data84;
        private String data85;
        private String data86;
        private String data87;
        private String data88;
        private String data89;
        private String data90;
        private String data91;
        private String data92;
        private String data93;
        private String data94;
        private String data95;
        private String data96;
        private String data97;
        private String data98;
        private String data99;
        private String data100;

        public MyVO(String data) {
            this.data1 = data;
            this.data2 = data;
            this.data3 = data;
            this.data4 = data;
            this.data5 = data;
            this.data6 = data;
            this.data7 = data;
            this.data8 = data;
            this.data9 = data;
            this.data10 = data;
            this.data11 = data;
            this.data12 = data;
            this.data13 = data;
            this.data14 = data;
            this.data15 = data;
            this.data16 = data;
            this.data17 = data;
            this.data18 = data;
            this.data19 = data;
            this.data20 = data;
            this.data21 = data;
            this.data22 = data;
            this.data23 = data;
            this.data24 = data;
            this.data25 = data;
            this.data26 = data;
            this.data27 = data;
            this.data28 = data;
            this.data29 = data;
            this.data30 = data;
            this.data31 = data;
            this.data32 = data;
            this.data33 = data;
            this.data34 = data;
            this.data35 = data;
            this.data36 = data;
            this.data37 = data;
            this.data38 = data;
            this.data39 = data;
            this.data40 = data;
            this.data41 = data;
            this.data42 = data;
            this.data43 = data;
            this.data44 = data;
            this.data45 = data;
            this.data46 = data;
            this.data47 = data;
            this.data48 = data;
            this.data49 = data;
            this.data50 = data;
            this.data51 = data;
            this.data52 = data;
            this.data53 = data;
            this.data54 = data;
            this.data55 = data;
            this.data56 = data;
            this.data57 = data;
            this.data58 = data;
            this.data59 = data;
            this.data60 = data;
            this.data61 = data;
            this.data62 = data;
            this.data63 = data;
            this.data64 = data;
            this.data65 = data;
            this.data66 = data;
            this.data67 = data;
            this.data68 = data;
            this.data69 = data;
            this.data70 = data;
            this.data71 = data;
            this.data72 = data;
            this.data73 = data;
            this.data74 = data;
            this.data75 = data;
            this.data76 = data;
            this.data77 = data;
            this.data78 = data;
            this.data79 = data;
            this.data80 = data;
            this.data81 = data;
            this.data82 = data;
            this.data83 = data;
            this.data84 = data;
            this.data85 = data;
            this.data86 = data;
            this.data87 = data;
            this.data88 = data;
            this.data89 = data;
            this.data90 = data;
            this.data91 = data;
            this.data92 = data;
            this.data93 = data;
            this.data94 = data;
            this.data95 = data;
            this.data96 = data;
            this.data97 = data;
            this.data98 = data;
            this.data99 = data;
            this.data100 = data;

        }
    }
}